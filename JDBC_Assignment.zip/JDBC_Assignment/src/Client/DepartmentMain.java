package Client;
import java.util.List;
import java.util.Scanner;
import model.Department;
import service.DepartmentService;
import service.DepartmentServiceImpl;

public class DepartmentMain {
	 public static void main(String[] args) {
	        DepartmentService service = new DepartmentServiceImpl();
	        Scanner sc = new Scanner(System.in);
	        int choice;

	        do {
	            System.out.println("\n==== Department Management ====");
	            System.out.println("1. Add Department");
	            System.out.println("2. Get Department by ID");
	            System.out.println("3. View All Departments");
	            System.out.println("4. Update Department");
	            System.out.println("5. Delete Department");
	            System.out.println("0. Exit");
	            System.out.print("Enter choice: ");
	            choice = sc.nextInt();

	            switch (choice) {
	                case 1:
	                    System.out.print("Enter DEPT ID: ");
	                    int id = sc.nextInt();
	                    System.out.print("Enter DEPT Name: ");
	                    String name = sc.next();
	                    System.out.print("Enter Location: ");
	                    String loc = sc.next();
	                    Department d = new Department();
	                    d.setDeptId(id);
	                    d.setDeptName(name);
	                    d.setLocation(loc);
	                    service.addDepartment(d);
	                    System.out.println("Department added.");
	                    break;
	                case 2:
	                    System.out.print("Enter DEPT ID: ");
	                    int findId = sc.nextInt();
	                    System.out.println(service.getDepartmentById(findId));
	                    break;
	                case 3:
	                    List<Department> list = service.getAllDepartments();
	                    list.forEach(System.out::println);
	                    break;
	                case 4:
	                    System.out.print("Enter DEPT ID to update: ");
	                    int updId = sc.nextInt();
	                    System.out.print("Enter new DEPT name: ");
	                    String newName = sc.next();
	                    System.out.print("Enter new location: ");
	                    String newLoc = sc.next();
	                    Department updated = new Department();
	                    updated.setDeptId(updId);
	                    updated.setDeptName(newName);
	                    updated.setLocation(newLoc);
	                    if (service.updateDepartment(updated)) {
	                        System.out.println("Updated successfully.");
	                    }
	                    break;
	                case 5:
	                    System.out.print("Enter DEPT ID to delete: ");
	                    int delId = sc.nextInt();
	                    service.deleteDepartment(delId);
	                    System.out.println("Deleted successfully.");
	                    break;
	                case 0:
	                    System.out.println("Exiting...");
	                    break;
	                default:
	                    System.out.println("Invalid choice.");
	            }
	        } while (choice != 0);

	        sc.close();
	    }
}
