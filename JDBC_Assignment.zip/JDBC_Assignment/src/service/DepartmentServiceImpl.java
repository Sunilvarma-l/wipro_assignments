package service;

import java.util.List;
import dao.*;
import model.Department;
import exception.DepartmentNotFoundException;

public class DepartmentServiceImpl implements DepartmentService {
    private DepartmentDao dao = new DepartmentDaoImpl();

    @Override
    public int addDepartment(Department department) {
        return dao.addDepartment(department);
    }

    @Override
    public Department getDepartmentById(int id) {
        Department dept = dao.getDepartmentById(id);
        if (dept == null) {
            throw new DepartmentNotFoundException("Department with ID " + id + " not found.");
        }
        return dept;
    }

    @Override
    public List<Department> getAllDepartments() {
        return dao.getAllDepartments();
    }

    @Override
    public boolean updateDepartment(Department department) {
        return dao.updateDepartment(department);
    }

    @Override
    public boolean deleteDepartment(int id) {
        boolean deleted = dao.deleteDepartment(id);
        if (!deleted) {
            throw new DepartmentNotFoundException("Department with ID " + id + " not found.");
        }
        return deleted;
    }
}
