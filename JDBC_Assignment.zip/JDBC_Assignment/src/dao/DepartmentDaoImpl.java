package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import exception.DepartmentException;
import model.Department;
import util.DbUtil;

public class DepartmentDaoImpl implements DepartmentDao {
	private Connection con = DbUtil.getConnection();

    @Override
    public int addDepartment(Department department) {
        try {
            PreparedStatement ps = con.prepareStatement("INSERT INTO department (dept_id, dept_name, location) VALUES (?, ?, ?)");
            ps.setInt(1, department.getDeptId());
            ps.setString(2, department.getDeptName());
            ps.setString(3, department.getLocation());
            return ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Failed to add department: " + e.getMessage());
        }
    }

    @Override
    public Department getDepartmentById(int id) {
        try {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM department WHERE dept_id = ?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Department d = new Department();
                d.setDeptId(rs.getInt("dept_id"));
                d.setDeptName(rs.getString("dept_name"));
                d.setLocation(rs.getString("location"));
                return d;
            }
            return null;
        } catch (SQLException e) {
            throw new RuntimeException("Failed to retrieve department: " + e.getMessage());
        }
    }

    @Override
    public List<Department> getAllDepartments() {
        List<Department> list = new ArrayList<>();
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM department");
            while (rs.next()) {
                Department d = new Department();
                d.setDeptId(rs.getInt("dept_id"));
                d.setDeptName(rs.getString("dept_name"));
                d.setLocation(rs.getString("location"));
                list.add(d);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to get all departments: " + e.getMessage());
        }
        return list;
    }

    @Override
    public boolean updateDepartment(Department department) {
        try {
            PreparedStatement ps = con.prepareStatement("UPDATE department SET dept_name = ?, location = ? WHERE dept_id = ?");
            ps.setString(1, department.getDeptName());
            ps.setString(2, department.getLocation());
            ps.setInt(3, department.getDeptId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new RuntimeException("Failed to update department: " + e.getMessage());
        }
    }

    @Override
    public boolean deleteDepartment(int id) {
        try {
            PreparedStatement ps = con.prepareStatement("DELETE FROM department WHERE dept_id = ?");
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new RuntimeException("Failed to delete department: " + e.getMessage());
        }
	}
}
