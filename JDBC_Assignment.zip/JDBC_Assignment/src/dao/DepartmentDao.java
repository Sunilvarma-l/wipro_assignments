package dao;
import java.util.List;
import model.Department;

public interface DepartmentDao {
    int addDepartment(Department department);
    Department getDepartmentById(int id);
    List<Department> getAllDepartments();
    boolean updateDepartment(Department department);
    boolean deleteDepartment(int id);
}
