package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import exception.DepartmentNotFoundException;

public class DbUtil {
public static Connection getConnection() {
		
		String url="jdbc:mysql://localhost:3306/wipro";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection(url,"root","sunil9059");
			return con;
		} catch (ClassNotFoundException e) {
			throw new DepartmentNotFoundException(e.getMessage());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new DepartmentNotFoundException(e.getMessage());
		}
		
	}

}
